// app.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="app-container">
      <h1>Angular Image Carousel</h1>
      <app-carousel></app-carousel>
    </div>
  `,
  styles: [`
    .app-container {
      font-family: Arial, sans-serif;
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      background-color: #f5f5f5;
    }
    
    h1 {
      margin-bottom: 30px;
      color: #333;
    }
  `]
})
export class AppComponent {
  title = 'angular-carousel-app';
}
// carousel.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';

interface Slide {
  imageUrl: string;
  linkUrl: string;
  title: string;
  description: string;
}

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit, OnDestroy {
  slides: Slide[] = [
    {
      imageUrl: '/assets/images/placeholder1.jpg', // Would normally be actual image paths
      linkUrl: 'https://www.amazon.com',
      title: 'Amazon',
      description: 'Click to visit Amazon\'s website'
    },
    {
      imageUrl: '/assets/images/placeholder2.jpg',
      linkUrl: 'https://claude.ai',
      title: 'Claude AI',
      description: 'Click to visit Claude\'s website'
    },
    {
      imageUrl: '/assets/images/placeholder3.jpg',
      linkUrl: 'https://www.anthropic.com',
      title: 'Anthropic',
      description: 'Click to visit Anthropic\'s website'
    }
  ];

  currentIndex = 0;
  slideInterval: any;
  autoAdvanceEnabled = true;
  
  ngOnInit(): void {
    this.startAutoAdvance();
  }

  ngOnDestroy(): void {
    this.stopAutoAdvance();
  }

  goToSlide(index: number): void {
    // Handle circular navigation
    if (index < 0) {
      this.currentIndex = this.slides.length - 1;
    } else if (index >= this.slides.length) {
      this.currentIndex = 0;
    } else {
      this.currentIndex = index;
    }
  }

  nextSlide(): void {
    this.goToSlide(this.currentIndex + 1);
  }

  previousSlide(): void {
    this.goToSlide(this.currentIndex - 1);
  }

  startAutoAdvance(): void {
    if (this.autoAdvanceEnabled) {
      this.slideInterval = setInterval(() => {
        this.nextSlide();
      }, 5000);
    }
  }

  stopAutoAdvance(): void {
    if (this.slideInterval) {
      clearInterval(this.slideInterval);
    }
  }

  pauseAutoAdvance(): void {
    this.stopAutoAdvance();
  }

  resumeAutoAdvance(): void {
    this.stopAutoAdvance();
    this.startAutoAdvance();
  }

  navigateToUrl(url: string): void {
    window.location.href = url;
  }
}